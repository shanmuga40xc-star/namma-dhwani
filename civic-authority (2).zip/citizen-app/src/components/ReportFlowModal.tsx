import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ChevronRight,
  Flag,
  ImagePlus,
  LocateFixed,
  MapPin,
  Mic,
  MicOff,
  Search,
  ShieldAlert,
  Sparkles,
  X,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import {
  BENGALURU_BOUNDS,
  COMPLAINT_CATEGORIES,
  SEVERITY_LEVELS,
} from '@shared/constants';
import { isInsideBengaluru, lookupConstituency } from '@shared/geo';
import { UI_STRINGS } from '@shared/i18n';
import { computePriorityScore } from '@shared/priority';
import type {
  AreaCluster,
  Complaint,
  ComplaintCategory,
  ConstituencyBoundary,
  DuplicateCheckResult,
  MediaAuthenticityMetadata,
  MediaInspectionResult,
  SeverityLevel,
  SupportedLanguage,
} from '@shared/types';
import { doc, setDoc, updateDoc, arrayUnion, increment } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { BengaluruMap } from './BengaluruMap';

interface ReportFlowModalProps {
  open: boolean;
  onClose: () => void;
  language: SupportedLanguage;
  simpleMode: boolean;
  constituencies: ConstituencyBoundary[];
  existingComplaints: Complaint[];
  existingClusters: AreaCluster[];
  onSubmitted: (message: string, newComplaintId?: string) => void;
}

function compressImageDataUrl(file: File, maxDim = 900): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result || ''));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.78));
      };
      img.onerror = () => reject(new Error('Could not read image'));
      img.src = String(reader.result || '');
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export const ReportFlowModal: React.FC<ReportFlowModalProps> = ({
  open,
  onClose,
  language,
  simpleMode,
  constituencies,
  existingComplaints,
  existingClusters,
  onSubmitted,
}) => {
  const t = UI_STRINGS[language] || UI_STRINGS.en;

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Tap 1: Photo or Voice + editable fields
  const [photoDataUrl, setPhotoDataUrl] = useState<string>('');
  const [mediaInfo, setMediaInfo] = useState<MediaInspectionResult | null>(null);
  const [appealNote, setAppealNote] = useState('');
  const [recording, setRecording] = useState(false);
  const [retainAudio, setRetainAudio] = useState(false);
  const [placeClues, setPlaceClues] = useState('');

  const [detectedLang, setDetectedLang] = useState<SupportedLanguage>(language);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [englishTranslation, setEnglishTranslation] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>('Potholes');
  const [severity, setSeverity] = useState<SeverityLevel>('Medium');
  const [aiMeta, setAiMeta] = useState<{
    suggestedCategory: ComplaintCategory;
    suggestedSeverity: SeverityLevel;
    suggestedTitle: string;
    suggestedDescription: string;
    hasAiSuggestion: boolean;
  }>({
    suggestedCategory: 'Potholes',
    suggestedSeverity: 'Medium',
    suggestedTitle: '',
    suggestedDescription: '',
    hasAiSuggestion: false,
  });

  // Tap 2: Location pin (NO ward/constituency dropdowns!)
  const [pinLat, setPinLat] = useState<number>(BENGALURU_BOUNDS.centerLat);
  const [pinLng, setPinLng] = useState<number>(BENGALURU_BOUNDS.centerLng);
  const [localityName, setLocalityName] = useState('Bengaluru');
  const [addressLabel, setAddressLabel] = useState('Bengaluru Center');
  const [boundaryFlagDone, setBoundaryFlagDone] = useState(false);
  const [gpsBusy, setGpsBusy] = useState(false);
  const [gpsNotice, setGpsNotice] = useState<string | null>(null);
  const [placeQuery, setPlaceQuery] = useState('');
  const [placeResults, setPlaceResults] = useState<
    Array<{ label: string; lat: number; lng: number; locality: string }>
  >([]);
  const [placeSearching, setPlaceSearching] = useState(false);

  // Tap 3: Duplicate check + privacy toggles
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [shareContactConsent, setShareContactConsent] = useState(false);
  const [dupResult, setDupResult] = useState<DuplicateCheckResult | null>(null);
  const [distinctOverridden, setDistinctOverridden] = useState(false);

  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const lookup = lookupConstituency(pinLat, pinLng, constituencies);
  const resolvedConstituency =
    lookup.constituency ||
    (lookup.insideServiceArea
      ? {
          id: 'bengaluru-central-desk',
          name: 'Bengaluru (Pending Boundary Import)',
          mlaName: 'Bengaluru Civic Desk',
          isDemo: false,
        }
      : null);

  function requestGpsLocation(silent = false) {
    if (!('geolocation' in navigator)) {
      if (!silent) {
        setGpsNotice(
          'GPS is unavailable in this browser. Search your Bengaluru street below or tap the map.'
        );
      }
      return;
    }
    setGpsBusy(true);
    if (!silent) setGpsNotice(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const nextLat = Number(pos.coords.latitude.toFixed(6));
        const nextLng = Number(pos.coords.longitude.toFixed(6));
        setGpsBusy(false);
        if (isInsideBengaluru(nextLat, nextLng)) {
          setPinLat(nextLat);
          setPinLng(nextLng);
          setBoundaryFlagDone(false);
          if (!silent) {
            setGpsNotice('GPS location detected in Bengaluru.');
          }
        } else if (!silent) {
          setGpsNotice(
            `Your device GPS (${nextLat.toFixed(3)}, ${nextLng.toFixed(3)}) is outside Bengaluru. Please search a Bengaluru area or tap the map.`
          );
        }
      },
      (err) => {
        setGpsBusy(false);
        if (!silent) {
          setGpsNotice(
            err.code === err.PERMISSION_DENIED
              ? 'Browser/preview blocked GPS permission. Search a Bengaluru landmark below or tap anywhere on the map.'
              : 'Could not read GPS signal right now. Search a Bengaluru landmark below or tap the map.'
          );
        }
      },
      { enableHighAccuracy: true, timeout: 9000, maximumAge: 60000 }
    );
  }

  async function handleSearchPlace() {
    const q = placeQuery.trim();
    if (q.length < 2) return;
    setPlaceSearching(true);
    setGpsNotice(null);
    try {
      const resp = await fetch(`/api/maps/search?q=${encodeURIComponent(q)}`);
      const data = (await resp.json()) as {
        results?: Array<{ label: string; lat: number; lng: number; locality: string }>;
      };
      const items = Array.isArray(data.results) ? data.results : [];
      setPlaceResults(items);
      if (items.length === 0) {
        setGpsNotice(`No Bengaluru places found for "${q}". Try a road, circle, or area name.`);
      }
    } catch {
      setGpsNotice('Place search unavailable right now; tap or drag the pin on the map.');
    } finally {
      setPlaceSearching(false);
    }
  }

  useEffect(() => {
    if (!open) return;
    setErrorMsg(null);
    setGpsNotice(null);
    setPlaceResults([]);
    setStep(1);
    setBoundaryFlagDone(false);
    setDistinctOverridden(false);
    setDupResult(null);
    requestGpsLocation(true);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    async function resolveAddr() {
      try {
        const resp = await fetch(`/api/maps/reverse-geocode?lat=${pinLat}&lng=${pinLng}`);
        const data = (await resp.json()) as {
          localityName?: string;
          addressLabel?: string;
        };
        if (!cancelled) {
          setLocalityName(data.localityName || 'Bengaluru');
          setAddressLabel(data.addressLabel || 'Bengaluru');
        }
      } catch {
        // ignore network blip cleanly
      }
    }
    void resolveAddr();
    return () => {
      cancelled = true;
    };
  }, [open, pinLat, pinLng]);

  async function handlePhotoSelected(file: File, source: 'live_camera' | 'gallery_upload') {
    setErrorMsg(null);
    setBusy(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error('Please sign in first.');

      // Preserve raw base64 header for EXIF before resized canvas if <3.5MB
      const compressed = await compressImageDataUrl(file);
      setPhotoDataUrl(compressed);

      const hashes = existingComplaints
        .filter((c) => c.mediaAuth?.sha256 || c.mediaAuth?.dHash)
        .slice(0, 60)
        .map((c) => ({
          complaintId: c.id,
          sha256: c.mediaAuth?.sha256,
          dHash: c.mediaAuth?.dHash,
        }));

      const resp = await fetch('/api/media/inspect-and-analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          imageBase64: compressed,
          mimeType: 'image/jpeg',
          captureSource: source,
          language,
          existingImageHashes: hashes,
        }),
      });
      const data = (await resp.json()) as {
        error?: string;
        media?: MediaInspectionResult;
        aiAnalysis?: {
          available: boolean;
          suggestedCategory: ComplaintCategory;
          suggestedSeverity: SeverityLevel;
          suggestedTitle: string;
          suggestedDescription: string;
          englishTranslation: string;
        };
      };
      if (!resp.ok) {
        throw new Error(data.error || 'Photo check failed');
      }
      if (data.media) {
        setMediaInfo(data.media);
        if (data.media.exifLatitude && data.media.exifLongitude) {
          setPinLat(data.media.exifLatitude);
          setPinLng(data.media.exifLongitude);
        }
      }
      if (data.aiAnalysis) {
        setCategory(data.aiAnalysis.suggestedCategory);
        setSeverity(data.aiAnalysis.suggestedSeverity);
        if (!title) setTitle(data.aiAnalysis.suggestedTitle);
        if (!description) setDescription(data.aiAnalysis.suggestedDescription);
        setEnglishTranslation(data.aiAnalysis.englishTranslation);
        setAiMeta({
          suggestedCategory: data.aiAnalysis.suggestedCategory,
          suggestedSeverity: data.aiAnalysis.suggestedSeverity,
          suggestedTitle: data.aiAnalysis.suggestedTitle,
          suggestedDescription: data.aiAnalysis.suggestedDescription,
          hasAiSuggestion: data.aiAnalysis.available,
        });
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to process photo.');
    } finally {
      setBusy(false);
    }
  }

  async function toggleVoiceRecord() {
    if (recording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      return;
    }

    setErrorMsg(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = async () => {
          setBusy(true);
          try {
            const token = await auth.currentUser?.getIdToken();
            if (!token) throw new Error('Sign in required.');
            const resp = await fetch('/api/ai/transcribe-voice', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({
                audioBase64: String(reader.result || ''),
                mimeType: blob.type || 'audio/webm',
                hintLanguage: language,
              }),
            });
            const data = (await resp.json()) as {
              available: boolean;
              detectedLanguage: SupportedLanguage;
              transcript: string;
              englishTranslation: string;
              suggestedTitle: string;
              suggestedCategory: ComplaintCategory;
              suggestedSeverity: SeverityLevel;
              placeClues: string;
              notice?: string;
            };
            if (!data.available || !data.transcript) {
              setErrorMsg(data.notice || 'Voice transcription unavailable; please type below.');
            } else {
              setDetectedLang(data.detectedLanguage);
              setDescription(data.transcript);
              setEnglishTranslation(data.englishTranslation);
              setTitle(data.suggestedTitle);
              setCategory(data.suggestedCategory);
              setSeverity(data.suggestedSeverity);
              if (data.placeClues) setPlaceClues(data.placeClues);
              setAiMeta({
                suggestedCategory: data.suggestedCategory,
                suggestedSeverity: data.suggestedSeverity,
                suggestedTitle: data.suggestedTitle,
                suggestedDescription: data.transcript,
                hasAiSuggestion: true,
              });
            }
          } catch (err) {
            setErrorMsg(err instanceof Error ? err.message : 'Voice processing failed.');
          } finally {
            setBusy(false);
          }
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      setErrorMsg('Microphone permission unavailable. You can type your complaint below.');
    }
  }

  async function goToDuplicateReviewStep() {
    setErrorMsg(null);
    if (!lookup.insideServiceArea || !resolvedConstituency) {
      setErrorMsg(t.outsideBengaluru);
      return;
    }
    setBusy(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error('Sign in required.');
      const resp = await fetch('/api/complaints/duplicate-check', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          candidate: {
            latitude: pinLat,
            longitude: pinLng,
            category,
            title: title || `${category} near ${localityName}`,
            description: description || `${category} reported at ${addressLabel}`,
            dHash: mediaInfo?.dHash,
          },
          existingComplaints: existingComplaints.map((c) => ({
            id: c.id,
            title: c.title,
            description: c.description,
            category: c.category,
            status: c.status,
            latitude: c.latitude,
            longitude: c.longitude,
            upvoteCount: c.upvoteCount,
            clusterId: c.clusterId,
            dHash: c.mediaAuth?.dHash,
          })),
          existingClusters,
        }),
      });
      const dup = (await resp.json()) as DuplicateCheckResult;
      setDupResult(dup);
      setStep(3);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to check nearby duplicates.');
    } finally {
      setBusy(false);
    }
  }

  async function handleUpvoteTier1(primaryId: string) {
    const user = auth.currentUser;
    if (!user) return;
    setBusy(true);
    try {
      const target = existingComplaints.find((c) => c.id === primaryId);
      if (target && !(target.upvoterUids || []).includes(user.uid)) {
        const nextUpvotes = target.upvoteCount + 1;
        const prio = computePriorityScore({
          severity: target.severity,
          category: target.category,
          upvoteCount: nextUpvotes,
          ageHours: 1,
        });
        await updateDoc(doc(db, 'complaints', primaryId), {
          upvoteCount: increment(1),
          upvoterUids: arrayUnion(user.uid),
          priorityScore: prio.score,
          priorityFactors: prio.factors,
          updatedAt: new Date().toISOString(),
        });
      }

      const pairId = `pair-${Date.now()}`;
      await setDoc(doc(db, 'duplicatePairs', pairId), {
        id: pairId,
        primaryComplaintId: primaryId,
        candidateTitle: title || `${category} report`,
        candidateDescription: description || 'Supported existing nearby report',
        candidateCategory: category,
        distanceMeters: dupResult?.tier1Matches[0]?.distanceMeters || 0,
        textSimilarity: dupResult?.tier1Matches[0]?.textSimilarity || 0,
        imageSimilarity: dupResult?.tier1Matches[0]?.imageSimilarity || 0,
        userDecision: 'auto_upvoted',
        reporterUid: user.uid,
        constituencyId: resolvedConstituency?.id || '',
        createdAt: new Date().toISOString(),
      });

      onSubmitted('Supported existing nearby report instead of filing a duplicate!', primaryId);
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to add support.');
    } finally {
      setBusy(false);
    }
  }

  async function handleFinalSubmit() {
    const user = auth.currentUser;
    if (!user || !lookup.insideServiceArea || !resolvedConstituency) return;
    if (mediaInfo?.blocked && !appealNote.trim()) {
      setErrorMsg('Please add an appeal note or capture a real live photo.');
      return;
    }

    setBusy(true);
    setErrorMsg(null);
    try {
      const now = new Date().toISOString();
      const id = `cmp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const finalTitle = (title.trim() || `${category} near ${localityName}`).slice(0, 175);
      const finalDesc = (description.trim() || `${category} issue at ${addressLabel}`).slice(0, 2400);

      let translated = englishTranslation.trim();
      if (!translated && detectedLang !== 'en') {
        const token = await user.getIdToken();
        const trResp = await fetch('/api/ai/translate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ text: finalDesc, sourceLanguage: detectedLang }),
        });
        const trData = (await trResp.json()) as { englishTranslation?: string };
        translated = trData.englishTranslation || finalDesc;
      }
      if (!translated) translated = finalDesc;

      const prio = computePriorityScore({
        severity,
        category,
        upvoteCount: 0,
        ageHours: 0,
      });

      // Handle Tier 2 cluster creation/linking (100m-500m)
      let clusterId = dupResult?.suggestedClusterId;
      if (!clusterId && (dupResult?.tier2ClusterMatches.length || 0) > 0) {
        clusterId = `cls-${Date.now()}`;
        const relatedIds = [id, ...dupResult!.tier2ClusterMatches.map((m) => m.complaintId)];
        await setDoc(doc(db, 'areaClusters', clusterId), {
          id: clusterId,
          constituencyId: resolvedConstituency.id,
          category,
          centroidLat: pinLat,
          centroidLng: pinLng,
          radiusMeters: 500,
          complaintIds: relatedIds,
          reportCount: relatedIds.length,
          status: 'active',
          createdAt: now,
          updatedAt: now,
        });
      } else if (clusterId) {
        await updateDoc(doc(db, 'areaClusters', clusterId), {
          complaintIds: arrayUnion(id),
          reportCount: increment(1),
          updatedAt: now,
        }).catch(() => null);
      }

      // Log labelled "This is a different problem" pair if Tier 1 existed
      if (distinctOverridden && dupResult?.tier1Matches[0]) {
        const pairId = `pair-${Date.now()}`;
        await setDoc(doc(db, 'duplicatePairs', pairId), {
          id: pairId,
          primaryComplaintId: dupResult.tier1Matches[0].complaintId,
          candidateTitle: finalTitle,
          candidateDescription: finalDesc,
          candidateCategory: category,
          distanceMeters: dupResult.tier1Matches[0].distanceMeters,
          textSimilarity: dupResult.tier1Matches[0].textSimilarity,
          imageSimilarity: dupResult.tier1Matches[0].imageSimilarity,
          userDecision: 'different_problem',
          reporterUid: user.uid,
          constituencyId: resolvedConstituency.id,
          createdAt: now,
        });
      }

      const mediaAuthPayload: MediaAuthenticityMetadata | undefined = mediaInfo
        ? {
            captureSource:
              mediaInfo.authenticityStatus === 'verified_live'
                ? 'live_camera'
                : 'gallery_upload',
            authenticityStatus: appealNote.trim()
              ? 'appealed_review'
              : mediaInfo.authenticityStatus,
            exifTimestamp: mediaInfo.exifTimestamp,
            exifLatitude: mediaInfo.exifLatitude,
            exifLongitude: mediaInfo.exifLongitude,
            hasC2paManifest: mediaInfo.hasC2paManifest,
            sha256: mediaInfo.sha256,
            dHash: mediaInfo.dHash,
            reusedComplaintId: mediaInfo.reusedComplaintId,
            aiDetectorScore: mediaInfo.aiDetectorScore,
            aiDetectorBlocked: Boolean(mediaInfo.blocked),
            appealNote: appealNote.trim() || undefined,
            appealedAt: appealNote.trim() ? now : undefined,
          }
        : undefined;

      const newComplaint: Complaint = {
        id,
        title: finalTitle,
        description: finalDesc,
        originalLanguage: detectedLang,
        originalText: finalDesc,
        englishTranslation: translated,
        category,
        aiSuggestedCategory: aiMeta.suggestedCategory,
        severity,
        aiSuggestedSeverity: aiMeta.suggestedSeverity,
        aiSuggestedTitle: aiMeta.suggestedTitle || finalTitle,
        aiSuggestedDescription: aiMeta.suggestedDescription || finalDesc,
        aiSuggestionAccepted: aiMeta.hasAiSuggestion,
        latitude: pinLat,
        longitude: pinLng,
        localityName,
        addressLabel,
        constituencyId: resolvedConstituency.id,
        constituencyName: resolvedConstituency.name,
        assignedMlaName: resolvedConstituency.mlaName,
        nearBoundary: lookup.nearBoundary,
        boundaryFlagged: boundaryFlagDone,
        status: 'Reported',
        isAnonymous,
        reporterUid: user.uid,
        reporterDisplayName: isAnonymous
          ? 'Anonymous Citizen'
          : user.displayName || 'Citizen',
        shareContactConsent: !isAnonymous && shareContactConsent,
        priorityScore: prio.score,
        priorityFactors: prio.factors,
        upvoteCount: 0,
        upvoterUids: [],
        ...(clusterId ? { clusterId } : {}),
        ...(photoDataUrl ? { photoDataUrl } : {}),
        ...(mediaAuthPayload ? { mediaAuth: mediaAuthPayload } : {}),
        audioRetained: retainAudio,
        escalatedToCm: false,
        ownerLabel: `${resolvedConstituency.mlaName} (${resolvedConstituency.name})`,
        timeline: [
          {
            status: 'Reported',
            actorLabel: isAnonymous ? 'Anonymous Citizen' : user.displayName || 'Citizen',
            note: `Routed automatically to ${resolvedConstituency.mlaName}, ${resolvedConstituency.name}`,
            timestamp: now,
          },
        ],
        aiBackgroundStatus: 'pending',
        isDemo: resolvedConstituency.isDemo,
        createdAt: now,
        updatedAt: now,
      };

      await setDoc(doc(db, 'complaints', id), newComplaint);

      // Run background AI enrichment asynchronously without blocking the 3-tap UI
      void (async () => {
        try {
          const token = await user.getIdToken();
          const resp = await fetch('/api/ai/background-enrich-report', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              title: finalTitle,
              description: translated,
              category,
              status: 'Reported',
              originalLanguage: detectedLang,
              localityName,
              constituencyName: resolvedConstituency.name,
            }),
          });
          if (!resp.ok) throw new Error('Background AI HTTP error');
          const bgData = (await resp.json()) as {
            aiStatus?: 'completed' | 'unavailable';
            draftReply?: string;
          };
          await updateDoc(doc(db, 'complaints', id), {
            aiBackgroundStatus: bgData.aiStatus || 'unavailable',
            ...(bgData.draftReply ? { aiDraftReply: bgData.draftReply } : {}),
            updatedAt: new Date().toISOString(),
          });
        } catch {
          await updateDoc(doc(db, 'complaints', id), {
            aiBackgroundStatus: 'unavailable',
            updatedAt: new Date().toISOString(),
          }).catch(() => null);
        }
      })();

      onSubmitted(
        `Report sent to ${resolvedConstituency.mlaName} (${resolvedConstituency.name})!`,
        id
      );
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to send report.');
    } finally {
      setBusy(false);
    }
  }

  async function handleFlagBoundary() {
    const user = auth.currentUser;
    if (!user || !lookup.constituency) return;
    try {
      const flagId = `flag-${Date.now()}`;
      await setDoc(doc(db, 'boundaryFlags', flagId), {
        id: flagId,
        latitude: pinLat,
        longitude: pinLng,
        matchedConstituencyId: lookup.constituency.id,
        matchedConstituencyName: lookup.constituency.name,
        citizenNote: `Citizen flagged boundary near ${addressLabel}`,
        reportedByUid: user.uid,
        status: 'open',
        createdAt: new Date().toISOString(),
      });
      setBoundaryFlagDone(true);
    } catch {
      setErrorMsg('Unable to send boundary flag right now.');
    }
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#0F2942]/60 p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Report a civic issue in 3 taps"
    >
      <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-t-2xl sm:rounded-2xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-[#E67E22]">
              Tap {step} of 3
            </div>
            <h2 className="font-display text-lg font-bold text-[#0F2942]">
              {step === 1
                ? '1. Photo or voice'
                : step === 2
                  ? '2. Confirm location pin'
                  : '3. Check & send report'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 p-5">
          {errorMsg && (
            <div className="flex items-start gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-900">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-700" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* STEP 1: PHOTO OR VOICE */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={busy}
                  className="flex min-h-[56px] items-center justify-center gap-2 rounded-xl bg-[#0F2942] px-4 py-3 text-sm font-semibold text-white hover:bg-[#173A5E]"
                >
                  <Camera className="h-5 w-5 text-[#E67E22]" />
                  <span>{t.takePhoto}</span>
                </button>
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  disabled={busy}
                  className="flex min-h-[56px] items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-[#0F2942] hover:bg-slate-50"
                >
                  <ImagePlus className="h-5 w-5" />
                  <span>{t.uploadGallery}</span>
                </button>
                <button
                  type="button"
                  onClick={() => void toggleVoiceRecord()}
                  disabled={busy}
                  className={`flex min-h-[56px] items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-semibold ${
                    recording
                      ? 'border-red-600 bg-red-600 text-white'
                      : 'border-slate-300 bg-white text-[#0F2942] hover:bg-slate-50'
                  }`}
                >
                  {recording ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5 text-[#E67E22]" />}
                  <span>{recording ? 'Stop speaking' : t.speakVoice}</span>
                </button>
              </div>

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void handlePhotoSelected(f, 'live_camera');
                }}
              />
              <input
                ref={galleryInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void handlePhotoSelected(f, 'gallery_upload');
                }}
              />

              {busy && (
                <div className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-medium text-blue-900">
                  Checking photo authenticity & preparing AI suggestions...
                </div>
              )}

              {photoDataUrl && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                  <img
                    src={photoDataUrl}
                    alt="Issue preview"
                    className="max-h-48 w-full rounded-lg object-cover"
                  />
                  {mediaInfo && (
                    <div className="mt-2 space-y-1 text-xs">
                      <div className="font-semibold text-[#0F2942]">
                        {mediaInfo.notice}
                      </div>
                      <div className="text-slate-600">
                        EXIF timestamp: {mediaInfo.exifTimestamp ? 'Present' : 'Not embedded'} ·
                        C2PA credentials: {mediaInfo.hasC2paManifest ? 'Present' : 'None'}
                      </div>
                      {mediaInfo.blocked && (
                        <div className="mt-2 space-y-2 rounded-lg border border-red-300 bg-red-50 p-2.5">
                          <div className="font-semibold text-red-900">
                            Blocked as high-confidence AI-generated image.
                          </div>
                          <input
                            type="text"
                            value={appealNote}
                            onChange={(e) => setAppealNote(e.target.value)}
                            placeholder="Appeal: explain why this is a genuine photo..."
                            className="w-full rounded border border-red-300 bg-white px-2.5 py-1.5 text-xs"
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Editable AI-assisted fields */}
              <div className="space-y-3 rounded-xl border border-slate-200 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Issue details (editable)
                  </span>
                  {aiMeta.hasAiSuggestion && (
                    <span className="inline-flex items-center gap-1 rounded bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-900 border border-amber-200">
                      <Sparkles className="h-3 w-3" />
                      {t.aiSuggestionBadge}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                      Category {aiMeta.hasAiSuggestion ? `(${t.aiSuggestionBadge})` : ''}
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as ComplaintCategory)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-[#0F2942]"
                    >
                      {COMPLAINT_CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  {!simpleMode && (
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Urgency {aiMeta.hasAiSuggestion ? `(${t.aiSuggestionBadge})` : ''}
                      </label>
                      <select
                        value={severity}
                        onChange={(e) => setSeverity(e.target.value as SeverityLevel)}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-[#0F2942]"
                      >
                        {SEVERITY_LEVELS.map((sev) => (
                          <option key={sev} value={sev}>
                            {sev}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Short title
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Deep pothole near bus stop"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Details (in your language or English)
                  </label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe the issue briefly..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>

                {englishTranslation && detectedLang !== 'en' && (
                  <div className="rounded-lg bg-slate-50 p-2.5 text-xs text-slate-700 border border-slate-200">
                    <span className="font-semibold">English translation for office staff:</span>{' '}
                    {englishTranslation}
                  </div>
                )}

                {placeClues && (
                  <div className="rounded-lg bg-blue-50 p-2 text-xs text-blue-900">
                    Voice landmark clue: "{placeClues}" — please verify on the map next.
                  </div>
                )}

                <label className="flex items-center gap-2 text-xs text-slate-600">
                  <input
                    type="checkbox"
                    checked={retainAudio}
                    onChange={(e) => setRetainAudio(e.target.checked)}
                  />
                  <span>Keep original voice recording (otherwise deleted right after transcription)</span>
                </label>
              </div>

              <button
                type="button"
                onClick={() => setStep(2)}
                className="flex w-full min-h-[52px] items-center justify-center gap-2 rounded-xl bg-[#0F2942] px-5 py-3 text-base font-bold text-white hover:bg-[#173A5E]"
              >
                <span>Next: {t.locationStep}</span>
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          )}

          {/* STEP 2: GPS DRAGGABLE PIN + PLACE SEARCH + AUTOMATIC MLA ROUTING (NO DROPDOWNS!) */}
          {step === 2 && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-slate-600">
                  Drag the orange pin, search a street/landmark, or tap anywhere in Bengaluru.
                </span>
                <button
                  type="button"
                  disabled={gpsBusy}
                  onClick={() => requestGpsLocation(false)}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-[#0F2942] hover:bg-slate-50 disabled:opacity-50"
                >
                  <LocateFixed className="h-4 w-4 text-[#E67E22]" />
                  <span>{gpsBusy ? 'Locating...' : 'Use GPS'}</span>
                </button>
              </div>

              {/* Bengaluru Place / Road Search (free-text OSM lookup — no ward dropdown!) */}
              <div className="space-y-1.5">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      value={placeQuery}
                      onChange={(e) => setPlaceQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          void handleSearchPlace();
                        }
                      }}
                      placeholder="Search Bengaluru street, circle, or area (e.g. Bandi Reddy Circle)..."
                      className="w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 py-2 text-xs text-[#0F2942]"
                    />
                  </div>
                  <button
                    type="button"
                    disabled={placeSearching || placeQuery.trim().length < 2}
                    onClick={() => void handleSearchPlace()}
                    className="rounded-lg bg-[#0F2942] px-3 py-2 text-xs font-bold text-white disabled:opacity-40"
                  >
                    {placeSearching ? '...' : 'Find'}
                  </button>
                </div>

                {placeResults.length > 0 && (
                  <div className="max-h-32 overflow-y-auto rounded-lg border border-slate-200 bg-white divide-y divide-slate-100">
                    {placeResults.map((resItem, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setPinLat(Number(resItem.lat.toFixed(6)));
                          setPinLng(Number(resItem.lng.toFixed(6)));
                          setLocalityName(resItem.locality);
                          setAddressLabel(resItem.label);
                          setPlaceResults([]);
                          setGpsNotice(null);
                          setBoundaryFlagDone(false);
                        }}
                        className="w-full px-3 py-2 text-left text-xs text-[#0F2942] hover:bg-amber-50"
                      >
                        {resItem.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {gpsNotice && (
                <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-950">
                  {gpsNotice}
                </div>
              )}

              <BengaluruMap
                mode="picker"
                pinLat={pinLat}
                pinLng={pinLng}
                constituencies={constituencies}
                onPinChange={(lat, lng) => {
                  setPinLat(lat);
                  setPinLng(lng);
                  setBoundaryFlagDone(false);
                }}
              />

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-sm">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                  <MapPin className="h-4 w-4 text-[#E67E22]" />
                  <span>{addressLabel}</span>
                </div>

                {lookup.insideServiceArea && resolvedConstituency ? (
                  <div className="mt-2 space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-[#0F2942]">
                      <CheckCircle2 className="h-5 w-5 text-[#15803D]" />
                      <span>
                        {t.goesToPrefix} {resolvedConstituency.mlaName},{' '}
                        {resolvedConstituency.name}
                      </span>
                    </div>
                    {lookup.nearBoundary && lookup.constituency && (
                      <div className="flex items-center justify-between rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-900 border border-amber-200">
                        <span>Pin is near a constituency boundary.</span>
                        {boundaryFlagDone ? (
                          <span className="font-semibold text-[#15803D]">Flagged for review</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => void handleFlagBoundary()}
                            className="inline-flex items-center gap-1 font-bold underline"
                          >
                            <Flag className="h-3.5 w-3.5" />
                            <span>{t.wrongArea}</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="mt-2 flex items-center gap-2 font-bold text-red-700">
                    <ShieldAlert className="h-5 w-5" />
                    <span>{t.outsideBengaluru}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="w-1/3 rounded-xl border border-slate-300 py-3 text-sm font-semibold text-slate-700"
                >
                  Back
                </button>
                <button
                  type="button"
                  disabled={!lookup.insideServiceArea || busy}
                  onClick={() => void goToDuplicateReviewStep()}
                  className="flex flex-1 min-h-[52px] items-center justify-center gap-2 rounded-xl bg-[#0F2942] px-5 py-3 text-base font-bold text-white disabled:opacity-40"
                >
                  <span>Next: Check & Send</span>
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: DUPLICATE CHECK + PRIVACY TOGGLES + SUBMIT */}
          {step === 3 && (
            <div className="space-y-4">
              {dupResult && dupResult.tier1Matches.length > 0 && !distinctOverridden && (
                <div className="rounded-xl border-2 border-[#E67E22] bg-amber-50 p-4 space-y-3">
                  <div className="font-bold text-[#0F2942]">
                    Someone already reported this issue within 100m!
                  </div>
                  <div className="rounded-lg bg-white p-3 border border-amber-200 text-sm">
                    <div className="font-semibold text-[#0F2942]">
                      {dupResult.tier1Matches[0].title}
                    </div>
                    <div className="text-xs text-slate-600 mt-1">
                      {dupResult.tier1Matches[0].distanceMeters}m away · Status:{' '}
                      {dupResult.tier1Matches[0].status} ·{' '}
                      {dupResult.tier1Matches[0].upvoteCount} citizen supports
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void handleUpvoteTier1(dupResult.tier1Matches[0].complaintId)}
                      className="flex-1 rounded-xl bg-[#0F2942] px-4 py-3 text-sm font-bold text-white"
                    >
                      Yes, support existing report
                    </button>
                    <button
                      type="button"
                      onClick={() => setDistinctOverridden(true)}
                      className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700"
                    >
                      This is a different problem
                    </button>
                  </div>
                </div>
              )}

              {dupResult && dupResult.tier2ClusterMatches.length > 0 && (
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900">
                  Found {dupResult.tier2ClusterMatches.length} related "{category}" issue(s) within
                  500m. Your report will automatically join an area cluster so it can be escalated
                  together.
                </div>
              )}

              {/* Privacy & Consent controls */}
              <div className="space-y-2.5 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm">
                <label className="flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="mt-1 h-4 w-4"
                  />
                  <span className="font-medium text-[#0F2942]">{t.anonymousToggle}</span>
                </label>

                {!isAnonymous && (
                  <label className="flex items-start gap-2.5">
                    <input
                      type="checkbox"
                      checked={shareContactConsent}
                      onChange={(e) => setShareContactConsent(e.target.checked)}
                      className="mt-1 h-4 w-4"
                    />
                    <span className="text-xs text-slate-700">
                      Allow the MLA office to see my email/phone for follow-up updates (DPDP
                      consent; otherwise only my name and report are shared).
                    </span>
                  </label>
                )}
              </div>

              <div className="rounded-lg border border-slate-200 p-3 text-xs text-slate-700">
                <div>
                  <span className="font-semibold">Summary:</span> {title || `${category} near ${localityName}`}
                </div>
                <div className="mt-1">
                  <span className="font-semibold">Routed to:</span> {resolvedConstituency?.mlaName} (
                  {resolvedConstituency?.name})
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-1/3 rounded-xl border border-slate-300 py-3 text-sm font-semibold text-slate-700"
                >
                  Back
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleFinalSubmit()}
                  className="flex flex-1 min-h-[54px] items-center justify-center gap-2 rounded-xl bg-[#E67E22] px-5 py-3 text-base font-bold text-white hover:bg-[#D36D16] disabled:opacity-50"
                >
                  <span>{busy ? 'Sending...' : t.submitReport}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
