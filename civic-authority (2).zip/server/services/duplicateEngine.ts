import { computeCivicTextSimilarity, haversineMeters } from '../../shared/geo.ts';
import type {
  AreaCluster,
  Complaint,
  DuplicateCheckCandidate,
  DuplicateCheckResult,
} from '../../shared/types.ts';
import { hammingSimilarityHex64 } from './mediaService.ts';

export interface DuplicateCandidateInput {
  latitude: number;
  longitude: number;
  category: Complaint['category'];
  title: string;
  description: string;
  dHash?: string;
}

/**
 * Two-tier Duplicate & Cluster Engine:
 * - Tier 1 (<= 100m): likely exact same issue -> prompts auto-upvote vs "This is a different problem".
 * - Tier 2 (100m..500m, same category): nearby related issues -> groups into an area cluster.
 */
export function runDuplicateEngine(
  candidate: DuplicateCandidateInput,
  existingComplaints: Array<
    Pick<
      Complaint,
      | 'id'
      | 'title'
      | 'description'
      | 'category'
      | 'status'
      | 'latitude'
      | 'longitude'
      | 'upvoteCount'
      | 'clusterId'
    > & { dHash?: string }
  >,
  existingClusters: AreaCluster[] = []
): DuplicateCheckResult {
  const tier1Matches: DuplicateCheckCandidate[] = [];
  const tier2ClusterMatches: DuplicateCheckCandidate[] = [];

  const candidateText = `${candidate.title} ${candidate.description}`.trim();

  for (const c of existingComplaints) {
    if (c.status === 'CONFIRMED RESOLVED' || c.status === 'Rejected') continue;

    const dist = haversineMeters(
      candidate.latitude,
      candidate.longitude,
      c.latitude,
      c.longitude
    );
    if (dist > 500) continue;

    const textSim = computeCivicTextSimilarity(
      candidateText,
      `${c.title} ${c.description}`
    );
    const imgSim =
      candidate.dHash && c.dHash ? hammingSimilarityHex64(candidate.dHash, c.dHash) : 0;
    const sameCategory = c.category === candidate.category;

    if (dist <= 100 && (sameCategory || textSim >= 0.35 || imgSim >= 0.85)) {
      tier1Matches.push({
        complaintId: c.id,
        title: c.title,
        category: c.category,
        status: c.status,
        distanceMeters: dist,
        textSimilarity: textSim,
        imageSimilarity: imgSim,
        upvoteCount: c.upvoteCount,
        tier: 'tier1_exact',
      });
    } else if (dist > 100 && dist <= 500 && sameCategory) {
      tier2ClusterMatches.push({
        complaintId: c.id,
        title: c.title,
        category: c.category,
        status: c.status,
        distanceMeters: dist,
        textSimilarity: textSim,
        imageSimilarity: imgSim,
        upvoteCount: c.upvoteCount,
        tier: 'tier2_cluster',
      });
    }
  }

  tier1Matches.sort((a, b) => a.distanceMeters - b.distanceMeters);
  tier2ClusterMatches.sort((a, b) => a.distanceMeters - b.distanceMeters);

  let suggestedClusterId: string | undefined;
  for (const cl of existingClusters) {
    if (cl.category !== candidate.category || cl.status === 'resolved') continue;
    const d = haversineMeters(
      candidate.latitude,
      candidate.longitude,
      cl.centroidLat,
      cl.centroidLng
    );
    if (d <= 500) {
      suggestedClusterId = cl.id;
      break;
    }
  }

  return {
    tier1Matches,
    tier2ClusterMatches,
    suggestedClusterId,
  };
}
