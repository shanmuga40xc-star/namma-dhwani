# Return Information About Proximity to Landmarks or Areas for Latitude/Longitude Coordinates

To retrieve detailed spatial context—such as nearby landmarks, containing areas
(like shopping malls or university campuses), sub-destinations (like individual
apartments or units), entrances, and navigation points—for a set of latitude and
longitude coordinates, use the `SearchDestinations` method in the Geocoding API
v4.

## Prerequisites

*   Familiarity with
    [Return the address for a set of latitude/longitude coordinates (reverse geocoding)](#).
*   A Google Cloud project with the **Geocoding API** enabled.
*   A valid API Key or OAuth 2.0 token with the
    `https://www.googleapis.com/auth/maps-platform.geocode` scope.

--------------------------------------------------------------------------------

## Endpoint and Request Structure

Make an HTTP `POST` request to the `destinations` endpoint:

```
POST https://geocode.googleapis.com/v4/geocode/destinations
```

### Required Headers

Header                    | Value                         | Description
:------------------------ | :---------------------------- | :----------
`Content-Type`            | `application/json`            | Specifies that the request body is JSON.
`X-Goog-Api-Key`          | `YOUR_API_KEY`                | Your Google Maps Platform API key (alternatively, use `Authorization: Bearer $TOKEN` for OAuth).
`X-Goog-FieldMask`        | Comma-separated fields or `*` | **Required.** Specifies which fields to return in the response. Leaving this blank results in an error.
`X-Goog-Maps-Solution-ID` | `gmp_git_agentskills_v1`      | Usage attribution header required for standard REST requests.

--------------------------------------------------------------------------------

## Requesting Proximity to Landmarks and Areas by Coordinates

To search using latitude and longitude coordinates, pass the `locationQuery`
object in the JSON body. To optimize performance and reduce latency, restrict
the `X-Goog-FieldMask` to the specific proximity and area fields you need:

*   `destinations.primary`: The main place identified at the coordinates.
*   `destinations.landmarks`: Notable nearby places with relational descriptions
    and distances.
*   `destinations.containingPlaces`: Larger entities or areas that encompass the
    primary place (e.g., a shopping center or campus).
*   `destinations.subDestinations`: More specific units or sections within the
    primary place.

### Example Request (`curl`)

```bash
curl -X POST -d '{
  "locationQuery": {
    "location": {
      "latitude": 37.37348780,
      "longitude": -122.05678064
    }
  },
  "languageCode": "en"
}' \
-H 'Content-Type: application/json' \
-H "X-Goog-Api-Key: YOUR_API_KEY" \
-H "X-Goog-Maps-Solution-ID: gmp_git_agentskills_v1" \
-H "X-Goog-FieldMask: destinations.primary,destinations.containingPlaces,destinations.landmarks,destinations.subDestinations" \
https://geocode.googleapis.com/v4/geocode/destinations
```

--------------------------------------------------------------------------------

## Filtering Location Queries (`placeFilter`)

When querying by coordinates, you can refine the types of structures or areas
returned by including a `placeFilter` inside the `locationQuery` object.

### 1. Filter by Structural Granularity (`structureType`)

*   `"BUILDING"`: Isolates individual buildings (useful for building outlines
    and specific structure details).
*   `"GROUNDS"`: Ensures the primary result is the overall complex or area
    (e.g., a shopping mall, apartment complex, or university campus).
*   `"SECTION"`: Focuses on subsections or units within a building.

### 2. Filter by Address Quality (`addressability`)

*   `"PRIMARY"`: Requires the main destination result to have a clear
    street-level address or name.
*   `"WEAK"`: Ensures that at least the primary place or one of its
    `subDestinations` has an address.
*   `"ANY"`: Disregards whether an address is present (recommended when you only
    need geometric attributes like building outlines, polygons, or navigation
    points).

### Example Request with Filters (`curl`)

```bash
curl -X POST -d '{
  "locationQuery": {
    "location": {
      "latitude": 37.37348780,
      "longitude": -122.05678064
    },
    "placeFilter": {
      "structureType": "BUILDING",
      "addressability": "PRIMARY"
    }
  },
  "languageCode": "en"
}' \
-H 'Content-Type: application/json' \
-H "X-Goog-Api-Key: YOUR_API_KEY" \
-H "X-Goog-Maps-Solution-ID: gmp_git_agentskills_v1" \
-H "X-Goog-FieldMask: destinations.primary,destinations.containingPlaces,destinations.landmarks" \
https://geocode.googleapis.com/v4/geocode/destinations
```

--------------------------------------------------------------------------------

## Understanding the Response

The API returns a `destinations` array. Below are the key fields used to
determine proximity to landmarks and relationship to surrounding areas:

### 1. `landmarks` (Proximity to Nearby Places)

Each object in the `landmarks[]` array provides context about a notable nearby
place:

*   `place`: Details of the landmark (`displayName`, `primaryType`, `types`,
    `formattedAddress`, `location`, `structureType`).
*   `relationalDescription`: A human-readable description of the spatial
    relationship (e.g., `"Near Chase Bank"`, `"Around the corner from Safeway"`,
    `"Down the road from Oil Changers"`).
*   `straightLineDistanceMeters`: The direct, as-the-crow-flies distance from
    the destination to the landmark in meters.
*   `travelDistanceMeters`: The actual travel distance along the road/path
    network in meters.
*   `tags`: Context tags indicating how the landmark is useful, such as
    `"ARRIVAL"` or `"ADDRESS"`.

### 2. `containingPlaces` (Encompassing Areas)

An array of `PlaceView` objects representing larger areas that contain the
`primary` destination (for example, a `shopping_mall` with `structureType:
"GROUNDS"` that contains a specific restaurant). Includes `displayPolygon`
(GeoJSON Polygon coordinates) outlining the boundary of the area.

### 3. `subDestinations` (Internal Areas/Units)

An array of more specific locations contained *within* the primary destination
(for example, individual apartments or suites inside a building).

### Example JSON Response

```json
{
  "destinations": [
    {
      "primary": {
        "place": "places/ChIJY8sv5-i2j4AR_S6BlDDR42w",
        "displayName": {
          "text": "Arby's",
          "languageCode": "en"
        },
        "primaryType": "fast_food_restaurant",
        "formattedAddress": "Arby's, 601 S Bernardo Ave, Sunnyvale, CA 94087, USA",
        "structureType": "BUILDING",
        "location": {
          "latitude": 37.3734545,
          "longitude": -122.0569327
        }
      },
      "containingPlaces": [
        {
          "place": "places/ChIJYfdAFum2j4ARIcL2tjME3Sw",
          "displayName": {
            "text": "Cherry Chase Shopping Center",
            "languageCode": "en"
          },
          "primaryType": "shopping_mall",
          "formattedAddress": "Cherry Chase Shopping Center, 663 S Bernardo Ave, Sunnyvale, CA 94087, USA",
          "structureType": "GROUNDS",
          "location": {
            "latitude": 37.3731231,
            "longitude": -122.0578211
          },
          "displayPolygon": {
            "type": "Polygon",
            "coordinates": [
              [
                [-122.0571122, 37.3714618],
                [-122.0570768, 37.3715743],
                [-122.0571122, 37.3714618]
              ]
            ]
          }
        }
      ],
      "landmarks": [
        {
          "place": {
            "place": "places/ChIJXXTe7Oi2j4ARoMTA-D6Hjpg",
            "displayName": {
              "text": "Chase Bank",
              "languageCode": "en"
            },
            "primaryType": "bank",
            "formattedAddress": "Chase Bank, 1234 W El Camino Real, Sunnyvale, CA 94087, USA",
            "structureType": "POINT",
            "location": {
              "latitude": 37.373579,
              "longitude": -122.057527
            }
          },
          "relationalDescription": {
            "text": "Near Chase Bank",
            "languageCode": "en"
          },
          "tags": [
            "ARRIVAL",
            "ADDRESS"
          ],
          "straightLineDistanceMeters": 61.182193756103516,
          "travelDistanceMeters": 63.075645446777344
        },
        {
          "place": {
            "place": "places/ChIJteQ0Fum2j4ARGi3tqK4Zm14",
            "displayName": {
              "text": "Safeway",
              "languageCode": "en"
            },
            "primaryType": "grocery_store",
            "formattedAddress": "Safeway, 639 S Bernardo Ave, Sunnyvale, CA 94087, USA",
            "structureType": "POINT",
            "location": {
              "latitude": 37.3727912,
              "longitude": -122.0581172
            }
          },
          "relationalDescription": {
            "text": "Around the corner from Safeway",
            "languageCode": "en"
          },
          "tags": [
            "ARRIVAL",
            "ADDRESS"
          ],
          "straightLineDistanceMeters": 158.65606689453125,
          "travelDistanceMeters": 131.1669921875
        }
      ]
    }
  ]
}
```
