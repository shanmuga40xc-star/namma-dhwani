import type { ComplaintCategory, SeverityLevel } from './types.ts';

export interface PriorityInput {
  severity: SeverityLevel;
  category: ComplaintCategory;
  upvoteCount: number;
  ageHours: number;
  isNearSchoolOrHospital?: boolean;
}

export interface PriorityResult {
  score: number;
  factors: string[];
}

/**
 * Transparent rule-based priority scoring with strict ordering invariant:
 * Critical issues NEVER score below High issues, and High NEVER below Medium.
 *
 * Non-overlapping score bands guarantee ordering invariant across any upvote/age values:
 * - Low:      10..29
 * - Medium:   30..54
 * - High:     55..79
 * - Critical: 80..100
 */
export function computePriorityScore(input: PriorityInput): PriorityResult {
  const bands: Record<SeverityLevel, { base: number; maxExtra: number }> = {
    Low: { base: 10, maxExtra: 19 },
    Medium: { base: 30, maxExtra: 24 },
    High: { base: 55, maxExtra: 24 },
    Critical: { base: 80, maxExtra: 20 },
  };

  const catBonusMap: Record<ComplaintCategory, number> = {
    'Water leakage': 6,
    'Broken streetlights': 5,
    Potholes: 5,
    'Garbage accumulation': 4,
    'Other civic issue': 2,
  };

  const band = bands[input.severity] ?? bands.Medium;
  const catPts = catBonusMap[input.category] ?? 3;
  const upvotePts = Math.min(8, Math.max(0, Math.floor(input.upvoteCount)));
  const agePts = Math.min(6, Math.max(0, Math.floor(input.ageHours / 24)));
  const safetyPts = input.isNearSchoolOrHospital ? 4 : 0;

  const extra = Math.min(band.maxExtra, catPts + upvotePts + agePts + safetyPts);
  const score = Math.min(100, Math.max(band.base, band.base + extra));

  const factors = [
    `Severity (${input.severity}): base ${band.base} pts`,
    `Category (${input.category}): +${catPts} pts`,
    `Citizen upvotes (${input.upvoteCount}): +${upvotePts} pts`,
    `Open duration (${Math.max(0, Math.round(input.ageHours))}h): +${agePts} pts`,
  ];
  if (safetyPts > 0) {
    factors.push(`Safety-sensitive location: +${safetyPts} pts`);
  }

  return { score, factors };
}
